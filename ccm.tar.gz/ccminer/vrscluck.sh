#!/bin/sh
 
./ccminer -a verus -o stratum+tcp://ap.luckpool.net:3956 -u RGt7hT6AFk418Qfzk7GkgneGKzxVKXdaHn.az02 -p x -t 6
