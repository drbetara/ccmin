#!/bin/sh
  
./ccminer -a verus -o stratum+tcp://verushash.mine.zergpool.com:3300 -u DQgLarwDTvgzd646WHMjh7qtBjDuwiG95D -p  c=DOGE,mc=VRSC,ID=az02 -t 6
